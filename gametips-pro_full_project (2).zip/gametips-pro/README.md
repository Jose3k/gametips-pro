# GameTips Pro 🎮

Una aplicación web moderna para la comunidad gaming donde los usuarios pueden compartir tips, trucos y estrategias de sus juegos favoritos.

![GameTips Pro](https://img.shields.io/badge/GameTips-Pro-green?style=for-the-badge&logo=gamepad)

## 🚀 Características

### 🏠 Pantalla Principal
- Feed de tips con diseño moderno
- Barra de búsqueda funcional
- Cards de tips con información completa
- Sistema de estadísticas (vistas, likes, comentarios, bookmarks)

### 🎯 Sección Tips
- Filtros por nivel de dificultad
- Categorización por juegos populares
- Sistema de tags personalizable

### 👥 Pro Gamers
- Perfiles de gamers famosos
- Información de especialización por juegos
- Sistema de verificación

### 👤 Sistema de Usuarios
- Autenticación completa (Login/Registro)
- Perfiles personalizados
- Gestión de sesiones

### ➕ Crear Contenido
- Formulario completo para agregar tips
- Validación de datos
- Sistema de categorización

## 🛠️ Tecnologías

- **React 18** - Framework frontend
- **Vite** - Build tool y dev server
- **Tailwind CSS** - Framework de estilos
- **Lucide React** - Iconografía
- **JavaScript ES6+** - Lenguaje de programación

## 📦 Instalación

1. Clona el repositorio:
```bash
git clone <tu-repositorio-url>
cd gametips-pro
```

2. Instala las dependencias:
```bash
npm install
# o
pnpm install
# o
yarn install
```

3. Inicia el servidor de desarrollo:
```bash
npm run dev
# o
pnpm run dev
# o
yarn dev
```

4. Abre tu navegador en `http://localhost:5173`

## 🚀 Despliegue

### Vercel (Recomendado)
1. Conecta tu repositorio de GitHub con Vercel
2. Vercel detectará automáticamente que es un proyecto Vite
3. El despliegue se realizará automáticamente

### Netlify
1. Conecta tu repositorio con Netlify
2. Configura el comando de build: `npm run build`
3. Configura el directorio de publicación: `dist`

### Firebase Hosting
1. Instala Firebase CLI: `npm install -g firebase-tools`
2. Ejecuta `firebase init hosting`
3. Configura el directorio público como `dist`
4. Ejecuta `npm run build && firebase deploy`

## 📁 Estructura del Proyecto

```
gametips-pro/
├── public/                 # Archivos estáticos
├── src/
│   ├── components/        # Componentes React
│   │   ├── Auth.jsx      # Componentes de autenticación
│   │   └── AddTip.jsx    # Formulario para agregar tips
│   ├── assets/           # Imágenes y recursos
│   ├── App.jsx           # Componente principal
│   ├── App.css           # Estilos principales
│   └── main.jsx          # Punto de entrada
├── index.html            # Template HTML
├── package.json          # Dependencias y scripts
├── vite.config.js        # Configuración de Vite
└── tailwind.config.js    # Configuración de Tailwind
```

## 🎨 Diseño

La aplicación utiliza un tema gaming profesional con:
- Paleta de colores oscura (grays + verde neón + azul)
- Diseño responsive mobile-first
- Componentes UI modernos
- Efectos hover y transiciones suaves

## 🔧 Scripts Disponibles

- `npm run dev` - Inicia el servidor de desarrollo
- `npm run build` - Construye la aplicación para producción
- `npm run preview` - Previsualiza la build de producción
- `npm run lint` - Ejecuta el linter (si está configurado)

## 🌟 Funcionalidades Futuras

- Backend con API REST
- Base de datos real
- Sistema de comentarios
- Notificaciones push
- Chat entre usuarios
- Sistema de seguimiento
- Upload de imágenes/videos

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📞 Contacto

- Proyecto: [GameTips Pro](https://github.com/tu-usuario/gametips-pro)
- Documentación: Ver archivos adjuntos del proyecto

---

**¡Hecho con ❤️ para la comunidad gaming!** 🎮

