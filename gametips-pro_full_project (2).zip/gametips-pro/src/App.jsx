import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx'
import { Heart, MessageCircle, Bookmark, Search, Home, Gamepad2, Users, User, Eye, ThumbsUp, Plus, LogOut } from 'lucide-react'
import { LoginForm, RegisterForm } from './components/Auth.jsx'
import { AddTipForm } from './components/AddTip.jsx'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('home')
  const [currentView, setCurrentView] = useState('main') // 'main', 'login', 'register', 'addTip'
  const [authMode, setAuthMode] = useState('login') // 'login' or 'register'
  const [user, setUser] = useState(null)
  const [tips, setTips] = useState([
    {
      id: 1,
      title: "Configuración perfecta de sensibilidad para Valorant",
      content: "La sensibilidad ideal depende de tu DPI y estilo de juego. Para la mayoría de jugadores profesionales...",
      author: {
        name: "ProPlayer",
        avatar: "/api/placeholder/40/40",
        isVerified: true
      },
      game: "Valorant",
      category: "Configuración",
      difficulty: "Intermedio",
      tags: ["sensibilidad", "configuracion", "aim"],
      stats: {
        views: 15420,
        likes: 892,
        comments: 67,
        bookmarks: 234
      },
      timeAgo: "4h"
    },
    {
      id: 2,
      title: "Truco secreto para conseguir armas legendarias",
      content: "En esta ubicación específica del mapa puedes encontrar un cofre oculto que contiene...",
      author: {
        name: "GamerExpert",
        avatar: "/api/placeholder/40/40",
        isVerified: false
      },
      game: "Free Fire",
      category: "Secretos",
      difficulty: "Avanzado",
      tags: ["secreto", "armas", "legendarias"],
      stats: {
        views: 8930,
        likes: 445,
        comments: 23,
        bookmarks: 156
      },
      timeAgo: "6h"
    },
    {
      id: 3,
      title: "Cómo hacer drift perfecto en carreras",
      content: "El drift perfecto requiere timing preciso y conocimiento de la física del juego...",
      author: {
        name: "SpeedMaster",
        avatar: "/api/placeholder/40/40",
        isVerified: true
      },
      game: "Need for Speed",
      category: "Técnicas",
      difficulty: "Intermedio",
      tags: ["drift", "carreras", "tecnica"],
      stats: {
        views: 12340,
        likes: 678,
        comments: 45,
        bookmarks: 189
      },
      timeAgo: "8h"
    }
  ])

  // Datos de ejemplo para juegos populares
  const popularGames = [
    { name: "Valorant", tips: 1247, icon: "🎯" },
    { name: "Free Fire", tips: 892, icon: "🔥" },
    { name: "Call of Duty", tips: 756, icon: "💀" },
    { name: "Fortnite", tips: 634, icon: "🏗️" },
    { name: "Apex Legends", tips: 523, icon: "⚡" }
  ]

  // Datos de ejemplo para pro gamers
  const proGamers = [
    {
      name: "Ninja",
      realName: "Tyler Blevins",
      followers: "18.2M",
      games: ["Fortnite", "Valorant"],
      isVerified: true,
      avatar: "/api/placeholder/60/60"
    },
    {
      name: "Shroud",
      realName: "Michael Grzesiek",
      followers: "10.6M",
      games: ["Valorant", "Apex Legends"],
      isVerified: true,
      avatar: "/api/placeholder/60/60"
    },
    {
      name: "ElRubius",
      realName: "Rubén Doblas",
      followers: "9.7M",
      games: ["Minecraft", "Among Us"],
      isVerified: true,
      avatar: "/api/placeholder/60/60"
    }
  ]

  const handleLogin = (userData) => {
    setUser(userData)
    setCurrentView('main')
  }

  const handleRegister = (userData) => {
    setUser(userData)
    setCurrentView('main')
  }

  const handleLogout = () => {
    setUser(null)
    setCurrentView('main')
  }

  const handleAddTip = (newTip) => {
    setTips([newTip, ...tips])
    setCurrentView('main')
    setActiveTab('home')
  }

  const TipCard = ({ tip }) => (
    <Card className="mb-4 bg-gray-900 border-gray-700 text-white">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src={tip.author.avatar} />
              <AvatarFallback>{tip.author.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center space-x-1">
                <span className="font-semibold text-sm">{tip.author.name}</span>
                {tip.author.isVerified && (
                  <Badge variant="secondary" className="bg-blue-600 text-white text-xs px-1 py-0">✓</Badge>
                )}
              </div>
              <div className="flex items-center space-x-2 text-xs text-gray-400">
                <span>{tip.game}</span>
                <span>•</span>
                <span>{tip.timeAgo}</span>
              </div>
            </div>
          </div>
          <Badge variant="outline" className="text-green-400 border-green-400">
            {tip.difficulty}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <CardTitle className="text-lg mb-2 text-white">{tip.title}</CardTitle>
        <CardDescription className="text-gray-300 mb-3">
          {tip.content}
        </CardDescription>
        <div className="flex flex-wrap gap-1 mb-3">
          {tip.tags.map((tag, index) => (
            <Badge key={index} variant="secondary" className="bg-gray-700 text-gray-300 text-xs">
              #{tag}
            </Badge>
          ))}
        </div>
        <div className="flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Eye className="w-4 h-4" />
              <span>{tip.stats.views.toLocaleString()}</span>
            </div>
            <button className="flex items-center space-x-1 hover:text-red-400 transition-colors">
              <Heart className="w-4 h-4" />
              <span>{tip.stats.likes}</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-blue-400 transition-colors">
              <MessageCircle className="w-4 h-4" />
              <span>{tip.stats.comments}</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-yellow-400 transition-colors">
              <Bookmark className="w-4 h-4" />
              <span>{tip.stats.bookmarks}</span>
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const GameCard = ({ game }) => (
    <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          <div className="text-2xl">{game.icon}</div>
          <div>
            <h3 className="font-semibold text-white">{game.name}</h3>
            <p className="text-sm text-green-400">{game.tips} tips</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const GamerCard = ({ gamer }) => (
    <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          <Avatar className="w-12 h-12">
            <AvatarImage src={gamer.avatar} />
            <AvatarFallback>{gamer.name[0]}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center space-x-1">
              <h3 className="font-semibold text-white">{gamer.name}</h3>
              {gamer.isVerified && (
                <Badge variant="secondary" className="bg-blue-600 text-white text-xs px-1 py-0">✓</Badge>
              )}
            </div>
            <p className="text-sm text-green-400">{gamer.followers} Followers</p>
            <p className="text-xs text-gray-400">{gamer.games.join(", ")}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Buscar tips, juegos, gamers..." 
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
            </div>
            
            {user && (
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white">Últimos Tips</h2>
                <Button
                  onClick={() => setCurrentView('addTip')}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Agregar Tip
                </Button>
              </div>
            )}
            
            {!user && (
              <div>
                <h2 className="text-xl font-bold text-white mb-3">Últimos Tips</h2>
              </div>
            )}
            
            {tips.map(tip => (
              <TipCard key={tip.id} tip={tip} />
            ))}
          </div>
        )
      
      case 'tips':
        return (
          <div className="space-y-4">
            <div className="flex space-x-2 mb-4">
              <Button variant="outline" size="sm" className="bg-green-600 text-white border-green-600">
                Principiante
              </Button>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                Intermedio
              </Button>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                Avanzado
              </Button>
            </div>
            
            <div>
              <h2 className="text-xl font-bold text-white mb-3">Juegos Populares</h2>
              <div className="grid grid-cols-1 gap-3">
                {popularGames.map((game, index) => (
                  <GameCard key={index} game={game} />
                ))}
              </div>
            </div>
          </div>
        )
      
      case 'gamers':
        return (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-bold text-white mb-3">Pro Gamers</h2>
              <div className="space-y-3">
                {proGamers.map((gamer, index) => (
                  <GamerCard key={index} gamer={gamer} />
                ))}
              </div>
            </div>
          </div>
        )
      
      case 'profile':
        if (!user) {
          return (
            <div className="space-y-4">
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6 text-center">
                  <Gamepad2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-white mb-2">¡Únete a GameTips Pro!</h2>
                  <p className="text-gray-400 mb-4">
                    Inicia sesión para acceder a tu perfil, guardar tips favoritos y compartir tu conocimiento gaming.
                  </p>
                  <div className="space-y-2">
                    <Button
                      onClick={() => {
                        setAuthMode('login')
                        setCurrentView('login')
                      }}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                    >
                      Iniciar Sesión
                    </Button>
                    <Button
                      onClick={() => {
                        setAuthMode('register')
                        setCurrentView('register')
                      }}
                      variant="outline"
                      className="w-full border-gray-600 text-gray-300 hover:text-white"
                    >
                      Crear Cuenta
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )
        }
        
        return (
          <div className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={user.profile?.avatar} />
                      <AvatarFallback>{user.username?.[0]?.toUpperCase() || 'U'}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="text-xl font-bold text-white">{user.profile?.displayName || user.username}</h2>
                      <p className="text-gray-400">Gamer apasionado</p>
                    </div>
                  </div>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    size="sm"
                    className="border-gray-600 text-gray-300 hover:text-white"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Salir
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-white">12</p>
                    <p className="text-sm text-gray-400">Tips</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">156</p>
                    <p className="text-sm text-gray-400">Seguidores</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">89</p>
                    <p className="text-sm text-gray-400">Siguiendo</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )
      
      default:
        return null
    }
  }

  // Renderizar vistas especiales
  if (currentView === 'login') {
    return (
      <LoginForm
        onLogin={handleLogin}
        onSwitchToRegister={() => {
          setAuthMode('register')
          setCurrentView('register')
        }}
      />
    )
  }

  if (currentView === 'register') {
    return (
      <RegisterForm
        onRegister={handleRegister}
        onSwitchToLogin={() => {
          setAuthMode('login')
          setCurrentView('login')
        }}
      />
    )
  }

  if (currentView === 'addTip') {
    return (
      <AddTipForm
        onSubmit={handleAddTip}
        onCancel={() => setCurrentView('main')}
      />
    )
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold">
            <span className="text-white">GameTips</span>
            <span className="text-green-400"> Pro</span>
          </h1>
          {user && (
            <div className="flex items-center space-x-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src={user.profile?.avatar} />
                <AvatarFallback className="text-xs">{user.username?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-gray-300">{user.username}</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto p-4 pb-20">
        {renderContent()}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700">
        <div className="max-w-md mx-auto flex justify-around py-2">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center p-2 ${
              activeTab === 'home' ? 'text-green-400' : 'text-gray-400'
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs mt-1">Home</span>
          </button>
          <button
            onClick={() => setActiveTab('tips')}
            className={`flex flex-col items-center p-2 ${
              activeTab === 'tips' ? 'text-green-400' : 'text-gray-400'
            }`}
          >
            <Gamepad2 className="w-6 h-6" />
            <span className="text-xs mt-1">Tips</span>
          </button>
          <button
            onClick={() => setActiveTab('gamers')}
            className={`flex flex-col items-center p-2 ${
              activeTab === 'gamers' ? 'text-green-400' : 'text-gray-400'
            }`}
          >
            <Users className="w-6 h-6" />
            <span className="text-xs mt-1">Gamers</span>
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center p-2 ${
              activeTab === 'profile' ? 'text-green-400' : 'text-gray-400'
            }`}
          >
            <User className="w-6 h-6" />
            <span className="text-xs mt-1">Perfil</span>
          </button>
        </div>
      </nav>
    </div>
  )
}

export default App

