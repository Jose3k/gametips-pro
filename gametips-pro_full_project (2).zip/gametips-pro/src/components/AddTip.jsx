import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { X, Plus, Upload, ArrowLeft } from 'lucide-react'

export function AddTipForm({ onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    gameId: '',
    category: '',
    difficulty: '',
    tags: []
  })
  const [newTag, setNewTag] = useState('')

  const games = [
    { id: 'valorant', name: 'Valorant' },
    { id: 'free-fire', name: 'Free Fire' },
    { id: 'call-of-duty', name: 'Call of Duty' },
    { id: 'fortnite', name: 'Fortnite' },
    { id: 'apex-legends', name: 'Apex Legends' },
    { id: 'minecraft', name: 'Minecraft' },
    { id: 'among-us', name: 'Among Us' }
  ]

  const categories = [
    { id: 'strategy', name: 'Estrategia' },
    { id: 'controls', name: 'Controles' },
    { id: 'settings', name: 'Configuración' },
    { id: 'easter-egg', name: 'Secretos' },
    { id: 'techniques', name: 'Técnicas' },
    { id: 'tips', name: 'Tips Generales' }
  ]

  const difficulties = [
    { id: 'beginner', name: 'Principiante' },
    { id: 'intermediate', name: 'Intermedio' },
    { id: 'advanced', name: 'Avanzado' }
  ]

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!formData.title || !formData.content || !formData.gameId || !formData.category || !formData.difficulty) {
      alert('Por favor completa todos los campos requeridos')
      return
    }
    
    const newTip = {
      id: Date.now(),
      ...formData,
      author: {
        name: 'Tu Usuario',
        avatar: '/api/placeholder/40/40',
        isVerified: false
      },
      game: games.find(g => g.id === formData.gameId)?.name || '',
      stats: {
        views: 0,
        likes: 0,
        comments: 0,
        bookmarks: 0
      },
      timeAgo: 'Ahora'
    }
    
    onSubmit(newTip)
  }

  const handleChange = (field, value) => {
    setFormData({
      ...formData,
      [field]: value
    })
  }

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, newTag.trim()]
      })
      setNewTag('')
    }
  }

  const removeTag = (tagToRemove) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(tag => tag !== tagToRemove)
    })
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      addTag()
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            onClick={onCancel}
            className="text-gray-400 hover:text-white mr-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver
          </Button>
          <h1 className="text-2xl font-bold text-white">Compartir Nuevo Tip</h1>
        </div>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Crear Tip</CardTitle>
            <CardDescription className="text-gray-400">
              Comparte tu conocimiento gaming con la comunidad
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-white">Título del Tip *</Label>
                <Input
                  id="title"
                  placeholder="Ej: Configuración perfecta de sensibilidad para Valorant"
                  value={formData.title}
                  onChange={(e) => handleChange('title', e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-white">Juego *</Label>
                  <Select value={formData.gameId} onValueChange={(value) => handleChange('gameId', value)}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Selecciona un juego" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      {games.map(game => (
                        <SelectItem key={game.id} value={game.id} className="text-white">
                          {game.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Categoría *</Label>
                  <Select value={formData.category} onValueChange={(value) => handleChange('category', value)}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Selecciona categoría" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      {categories.map(category => (
                        <SelectItem key={category.id} value={category.id} className="text-white">
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Dificultad *</Label>
                  <Select value={formData.difficulty} onValueChange={(value) => handleChange('difficulty', value)}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Selecciona dificultad" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      {difficulties.map(difficulty => (
                        <SelectItem key={difficulty.id} value={difficulty.id} className="text-white">
                          {difficulty.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="content" className="text-white">Contenido del Tip *</Label>
                <Textarea
                  id="content"
                  placeholder="Describe tu tip en detalle. Incluye pasos específicos, configuraciones, o estrategias..."
                  value={formData.content}
                  onChange={(e) => handleChange('content', e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 min-h-32"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">Tags</Label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {formData.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="bg-gray-600 text-white">
                      #{tag}
                      <button
                        type="button"
                        onClick={() => removeTag(tag)}
                        className="ml-1 hover:text-red-400"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Agregar tag (ej: sensibilidad, aim, configuracion)"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                  />
                  <Button
                    type="button"
                    onClick={addTag}
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:text-white"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Imágenes/Videos (Opcional)</Label>
                <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-400 mb-2">Arrastra archivos aquí o haz clic para seleccionar</p>
                  <Button variant="outline" className="border-gray-600 text-gray-300">
                    Seleccionar Archivos
                  </Button>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  className="flex-1 border-gray-600 text-gray-300 hover:text-white"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  Publicar Tip
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

